# Telemetry & Threat Analysis Honeypot — Supabase build

## Before deploying
1. In Supabase SQL Editor, ensure `public.telemetry_events` exists with:
   - `id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY`
   - `timestamp TIMESTAMPTZ NOT NULL`
   - `ip_address TEXT`
   - `method TEXT NOT NULL`
   - `path TEXT NOT NULL`
   - `user_agent TEXT`
   - `classification TEXT NOT NULL`
2. In Render > your web service > Environment, set `DATABASE_URL` to the Supabase Session Pooler URI (port 5432). Do not commit the URI to Git.
3. Build command: `pip install -r requirements.txt`
4. Start command: `gunicorn app:app`
5. Deploy only after checking the SQL table and keeping a separate copy of your telemetry backup.

## Storage behavior
When `DATABASE_URL` is set, new requests are inserted into Supabase and the dashboard reads from Supabase. If database operations fail, the app logs the error and attempts to write that event to a local `telemetry.jsonl` fallback. Local Render files are ephemeral and should not be treated as durable storage.

## Important
- This ZIP intentionally excludes `.git`, `app_backup.py`, and local telemetry backups.
- Existing JSONL history is not automatically imported into Supabase.
- Validate the deployment and `/dashboard` after deploy. The package cannot verify your private Supabase credentials or remote database connectivity.
